def maior_n():
    for n in numeros:
        print("Digite um número: ")
        return n