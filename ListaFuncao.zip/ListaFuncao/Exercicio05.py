def eh_primo():
    numero = 1
    if numero %1 == 0 and numero %numero == 0:
        return True
    else:
        return False
