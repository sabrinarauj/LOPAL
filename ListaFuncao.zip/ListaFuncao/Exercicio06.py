def contar_vogais(texto):
    vogais = "aeiouAEIOU"
    contador = 0

    