def dobro(num):
    dobro_num = num * 2
    return dobro_num

num = int(input("Digite um número para descobrir o dobro: "))
resultado = dobro(num)

print(f"O dobro do número {num} é {resultado}")
