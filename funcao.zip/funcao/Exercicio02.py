def maior(n1, n2):
   if n1 > n2:
      return n1
   else:
    return n2

n1 = int(input("Digite um valor: "))
n2 = int(input("Digite outro valor: "))
print(maior(n1, n2))