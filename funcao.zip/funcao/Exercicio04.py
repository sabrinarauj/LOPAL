#Correção - Exercício 04
def calcular_fatorial(n):
    fatorial = 1
    for i in range(1, n + 1):
        fatorial *= i
        return fatorial

numero = int(input("Digite um número para calcular o fatorial: "))
resultado = calcular_fatorial(numero)
print(resultado)
