"""
def calcular_media(nota1, nota2):
    media = (nota1 + nota2)/2
    return media

nota1 = float(input("Digite a primeira nota: "))
nota2 = float(input("Digite a segunda nota: "))

resultado = calcular_media(nota1, nota2)

print(f"A média entre as notas {nota1} e {nota2} é {resultado}")
"""
"""
def minha_funcao():
    x = 10
    print(x)
minha_funcao()
#print(x) --> da erro pois só existe x dentro da função pep8
"""
"""
y = 20 #variavel global
def outra_funcao():
    print(y) #pode acessar o valor global
outra_funcao()
print(y) #tambem pode usar aqui

# Não utilizar a variavel global antes de criar a função
"""
"""
def mudar_valor():
    global z
    z = 100

z = 5
mudar_valor()
print(z)
"""
"""
def diz_ola():
    print("olá")
resultado = diz_ola()
print(resultado)
# Retorna o none, que representa nada, sem valor. Nesse caso, precisaria do return
"""


